package com.example.mediaeditor

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class Mode(val label: String, val pickMime: String, val needsAudio: Boolean) {
    CUT_VIDEO("قص فيديو", "video/*", false),
    CUT_AUDIO("قص صوت", "audio/*", false),
    REMOVE_AUDIO("إزالة الصوت", "video/*", false),
    REPLACE_AUDIO("تركيب صوت", "video/*", true);

    val isAudioOutput: Boolean get() = this == CUT_AUDIO
}

class Editor(private val context: Context) {

    fun durationMs(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    private fun clipped(uri: Uri, startMs: Long, endMs: Long, totalMs: Long): MediaItem {
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
        if (endMs in 1 until totalMs) clip.setEndPositionMs(endMs)
        return MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clip.build())
            .build()
    }

    /** يجب استدعاؤها من الخيط الرئيسي (Main). */
    suspend fun export(
        mode: Mode,
        mainUri: Uri,
        audioUri: Uri?,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit
    ): File = coroutineScope {
        val total = durationMs(mainUri)
        val ext = if (mode.isAudioOutput) "m4a" else "mp4"
        val out = File(context.cacheDir, "out_${System.currentTimeMillis()}.$ext")
        val done = CompletableDeferred<Unit>()

        val builder = Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    done.complete(Unit)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    done.completeExceptionally(exportException)
                }
            })
        if (!mode.isAudioOutput) builder.setVideoMimeType(MimeTypes.VIDEO_H264)
        val transformer = builder.build()

        val mainItem = clipped(mainUri, startMs, endMs, total)

        when (mode) {
            Mode.CUT_VIDEO, Mode.CUT_AUDIO ->
                transformer.start(EditedMediaItem.Builder(mainItem).build(), out.absolutePath)

            Mode.REMOVE_AUDIO ->
                transformer.start(
                    EditedMediaItem.Builder(mainItem).setRemoveAudio(true).build(),
                    out.absolutePath
                )

            Mode.REPLACE_AUDIO -> {
                requireNotNull(audioUri) { "اختر ملف الصوت أولاً" }
                val effectiveEnd = if (endMs in 1 until total) endMs else total
                val videoLen = (effectiveEnd - startMs).coerceAtLeast(0L)
                val audioTotal = durationMs(audioUri)
                val audioItem = clipped(audioUri, 0L, videoLen, audioTotal)

                val videoSeq = EditedMediaItemSequence(
                    listOf(EditedMediaItem.Builder(mainItem).setRemoveAudio(true).build())
                )
                val audioSeq = EditedMediaItemSequence(
                    listOf(EditedMediaItem.Builder(audioItem).setRemoveVideo(true).build())
                )
                transformer.start(Composition.Builder(videoSeq, audioSeq).build(), out.absolutePath)
            }
        }

        val poller = launch {
            val holder = ProgressHolder()
            while (isActive) {
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress)
                }
                delay(300)
            }
        }

        try {
            done.await()
        } catch (e: Throwable) {
            transformer.cancel()
            throw e
        } finally {
            poller.cancel()
        }
        out
    }

    /** يحفظ الملف في المعرض: Movies/MediaEditor أو Music/MediaEditor */
    fun saveToGallery(file: File, audio: Boolean): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            if (audio) {
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/MediaEditor")
            } else {
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MediaEditor")
            }
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values) ?: return false
        return try {
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            file.delete()
            true
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            false
        }
    }
}
