package com.example.mediaeditor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class Mode(
    val label: String,
    val sub: String,
    val icon: ImageVector,
    val pickMime: String,
    val needsAudio: Boolean
) {
    CUT_VIDEO("قص فيديو", "اختر البداية والنهاية", Icons.Rounded.ContentCut, "video/*", false),
    CUT_AUDIO("قص صوت", "مقطع صوتي بدقة الثانية", Icons.Rounded.GraphicEq, "audio/*", false),
    REMOVE_AUDIO("إزالة الصوت", "فيديو صامت", Icons.Rounded.VolumeOff, "video/*", false),
    REPLACE_AUDIO("تركيب صوت", "استبدل صوت الفيديو", Icons.Rounded.LibraryMusic, "video/*", true);

    val isAudioOutput: Boolean get() = this == CUT_AUDIO
}

class Editor(private val context: Context) {

    fun durationMs(uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    fun displayName(uri: Uri): String {
        return try {
            context.contentResolver.query(
                uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
            )?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        } ?: "ملف مختار"
    }

    /** لقطة من الفيديو عند وقت معين (للمعاينة). */
    fun frameAt(uri: Uri, ms: Long): Bitmap? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            val bmp = r.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: return null
            val w = 480
            val h = (bmp.height * w / bmp.width.toFloat()).toInt().coerceAtLeast(1)
            Bitmap.createScaledBitmap(bmp, w, h, true)
        } catch (e: Exception) {
            null
        } finally {
            r.release()
        }
    }

    private fun clipped(uri: Uri, startMs: Long, endMs: Long, totalMs: Long): MediaItem {
        val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
        if (endMs in 1 until totalMs) clip.setEndPositionMs(endMs)
        return MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(clip.build())
            .build()
    }

    /** يجب استدعاؤها من الخيط الرئيسي (Main). */
    suspend fun export(
        mode: Mode,
        mainUri: Uri,
        audioUri: Uri?,
        startMs: Long,
        endMs: Long,
        onProgress: (Int) -> Unit
    ): File = coroutineScope {
        val total = durationMs(mainUri)
        val ext = if (mode.isAudioOutput) "m4a" else "mp4"
        val out = File(context.cacheDir, "MediaEditor_${System.currentTimeMillis()}.$ext")
        val done = CompletableDeferred<Unit>()

        val builder = Transformer.Builder(context)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    done.complete(Unit)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    done.completeExceptionally(exportException)
                }
            })
        if (!mode.isAudioOutput) builder.setVideoMimeType(MimeTypes.VIDEO_H264)
        val transformer = builder.build()

        val mainItem = clipped(mainUri, startMs, endMs, total)

        when (mode) {
            Mode.CUT_VIDEO, Mode.CUT_AUDIO ->
                transformer.start(EditedMediaItem.Builder(mainItem).build(), out.absolutePath)

            Mode.REMOVE_AUDIO ->
                transformer.start(
                    EditedMediaItem.Builder(mainItem).setRemoveAudio(true).build(),
                    out.absolutePath
                )

            Mode.REPLACE_AUDIO -> {
                requireNotNull(audioUri) { "اختر ملف الصوت أولاً" }
                val effectiveEnd = if (endMs in 1 until total) endMs else total
                val videoLen = (effectiveEnd - startMs).coerceAtLeast(0L)
                val audioTotal = durationMs(audioUri)
                val audioItem = clipped(audioUri, 0L, videoLen, audioTotal)

                val videoSeq = EditedMediaItemSequence(
                    listOf(EditedMediaItem.Builder(mainItem).setRemoveAudio(true).build())
                )
                val audioSeq = EditedMediaItemSequence(
                    listOf(EditedMediaItem.Builder(audioItem).setRemoveVideo(true).build())
                )
                transformer.start(Composition.Builder(videoSeq, audioSeq).build(), out.absolutePath)
            }
        }

        val poller = launch {
            val holder = ProgressHolder()
            while (isActive) {
                if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) {
                    onProgress(holder.progress)
                }
                delay(250)
            }
        }

        try {
            done.await()
        } catch (e: Throwable) {
            transformer.cancel()
            throw e
        } finally {
            poller.cancel()
        }
        out
    }

    /** يحفظ الملف في المعرض ويرجع Uri الناتج. */
    fun saveToGallery(file: File, audio: Boolean): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            if (audio) {
                put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/MediaEditor")
            } else {
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/MediaEditor")
            }
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = if (audio) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val resolver = context.contentResolver
        val uri = resolver.insert(collection, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { os -> file.inputStream().use { it.copyTo(os) } }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            file.delete()
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}
