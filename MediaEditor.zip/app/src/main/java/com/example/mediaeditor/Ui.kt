package com.example.mediaeditor

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

@Composable
fun AppBackground(content: @Composable BoxScope.() -> Unit) {
    val inf = rememberInfiniteTransition(label = "bg")
    val drift by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Pal.Bg1, Pal.Bg2)))
            .drawBehind {
                val r = size.width * 0.9f
                val c1 = Offset(size.width * (0.8f + 0.1f * drift), size.height * 0.08f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Pal.Purple.copy(alpha = 0.40f), Color.Transparent),
                        center = c1, radius = r
                    ), radius = r, center = c1
                )
                val c2 = Offset(size.width * (0.1f + 0.15f * drift), size.height * 0.75f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(Pal.Cyan.copy(alpha = 0.22f), Color.Transparent),
                        center = c2, radius = r
                    ), radius = r, center = c2
                )
            },
        content = content
    )
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .then(modifier)
            .background(Pal.Glass)
            .border(1.dp, Pal.Border, shape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun IconBadge(icon: ImageVector, size: Int = 44, brush: Brush = Pal.Accent) {
    Box(
        Modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size / 3).dp))
            .background(brush),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size((size * 0.55f).dp))
    }
}

@Composable
fun SectionTitle(icon: ImageVector, title: String, subtitle: String? = null) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon, 40)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = Pal.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = Pal.Muted, fontSize = 12.sp)
        }
    }
}

@Composable
fun ModeCard(mode: Mode, selected: Boolean, enabled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val scale by animateFloatAsState(
        if (selected) 1f else 0.96f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy), label = "scale"
    )
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .scale(scale)
            .clip(shape)
            .background(if (selected) Pal.Accent else SolidColor(Pal.Glass))
            .border(1.dp, if (selected) Color.Transparent else Pal.Border, shape)
            .clickable(enabled = enabled) { onClick() }
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (selected) Color(0x33FFFFFF) else Color(0x1FFFFFFF)),
            contentAlignment = Alignment.Center
        ) {
            Icon(mode.icon, null, tint = if (selected) Color.White else Pal.Cyan, modifier = Modifier.size(22.dp))
        }
        Text(mode.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(mode.sub, color = if (selected) Color(0xDDFFFFFF) else Pal.Muted, fontSize = 11.sp)
    }
}

@Composable
fun GradientButton(
    text: String,
    icon: ImageVector,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    brush: Brush = Pal.Accent,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .fillMaxWidth()
            .height(58.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(brush)
            .clickable(enabled = enabled) { onClick() },
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun SoftButton(text: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .height(48.dp)
            .clip(shape)
            .background(Color(0x1FFFFFFF))
            .border(1.dp, Pal.Border, shape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Pal.Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Pal.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun Waveform(modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "wave")
    val t by inf.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "t"
    )
    Canvas(modifier) {
        val n = 30
        val gap = 5.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val brush = Brush.verticalGradient(listOf(Pal.Cyan, Pal.Purple))
        val twoPi = (2.0 * PI).toFloat()
        for (i in 0 until n) {
            val a = abs(sin((t + i * 0.09f) * twoPi) * cos((t * 2f + i * 0.05f) * twoPi))
            val h = size.height * (0.15f + 0.85f * a)
            drawRoundRect(
                brush = brush,
                topLeft = Offset(i * (bw + gap), (size.height - h) / 2f),
                size = Size(bw, h),
                cornerRadius = CornerRadius(bw / 2f)
            )
        }
    }
}

@Composable
private fun DigitBox(value: String, maxLen: Int, enabled: Boolean, onValue: (String) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .width(58.dp)
            .height(50.dp)
            .clip(shape)
            .background(Color(0x1FFFFFFF))
            .border(1.dp, Pal.Border, shape),
        contentAlignment = Alignment.Center
    ) {
        BasicTextField(
            value = value,
            onValueChange = { v -> onValue(v.filter { it.isDigit() }.take(maxLen)) },
            enabled = enabled,
            singleLine = true,
            textStyle = TextStyle(
                color = Pal.Text, fontSize = 20.sp,
                fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            ),
            cursorBrush = SolidColor(Pal.Cyan),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun StepButton(icon: ImageVector, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0x1FFFFFFF))
            .clickable(enabled = enabled) { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Pal.Cyan, modifier = Modifier.size(20.dp))
    }
}

/** إدخال وقت بالدقيقة والثانية مع أزرار ±1 ثانية. */
@Composable
fun TimeRow(label: String, valueMs: Long, maxMs: Long, enabled: Boolean, onChange: (Long) -> Unit) {
    var min by remember { mutableStateOf((valueMs / 60000).toString()) }
    var sec by remember { mutableStateOf(((valueMs / 1000) % 60).toString()) }

    LaunchedEffect(valueMs) {
        val cur = (min.toLongOrNull() ?: 0L) * 60000 + (sec.toLongOrNull() ?: 0L) * 1000
        if (cur != valueMs / 1000 * 1000) {
            min = (valueMs / 60000).toString()
            sec = ((valueMs / 1000) % 60).toString()
        }
    }

    fun push(m: String, s: String) {
        val v = ((m.toLongOrNull() ?: 0L) * 60000 + (s.toLongOrNull() ?: 0L) * 1000).coerceIn(0L, maxMs)
        onChange(v)
    }

    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(label, color = Pal.Text, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text("دقيقة : ثانية", color = Pal.Muted, fontSize = 11.sp)
        }
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                StepButton(Icons.Rounded.Remove, enabled) {
                    onChange((((valueMs / 1000) - 1) * 1000).coerceAtLeast(0L))
                }
                DigitBox(min, 3, enabled) { min = it; push(it, sec) }
                Text(":", color = Pal.Muted, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                DigitBox(sec, 2, enabled) { sec = it; push(min, it) }
                StepButton(Icons.Rounded.Add, enabled) {
                    onChange((((valueMs / 1000) + 1) * 1000).coerceAtMost(maxMs))
                }
            }
        }
    }
}
