package com.example.mediaeditor

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg1 = Color(0xFF0A0A18)
    val Bg2 = Color(0xFF15102B)
    val Purple = Color(0xFF7C5CFF)
    val Cyan = Color(0xFF22D3EE)
    val Pink = Color(0xFFFF5CAA)
    val Glass = Color(0x14FFFFFF)
    val Border = Color(0x26FFFFFF)
    val Text = Color(0xFFF4F4FF)
    val Muted = Color(0xFFA6A6C8)
    val Ok = Color(0xFF34D399)
    val Err = Color(0xFFFF6B81)
    val Accent: Brush = Brush.linearGradient(listOf(Purple, Cyan))
    val Warm: Brush = Brush.linearGradient(listOf(Pink, Purple))
}
