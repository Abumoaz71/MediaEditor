package com.example.mediaeditor

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(modifier = Modifier.fillMaxSize()) { App() }
                }
            }
        }
    }
}

private fun fmt(ms: Long): String {
    val s = ms / 1000
    return "%02d:%02d".format(s / 60, s % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val editor = remember { Editor(context.applicationContext) }

    var mode by remember { mutableStateOf(Mode.CUT_VIDEO) }
    var mainUri by remember { mutableStateOf<Uri?>(null) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startF by remember { mutableFloatStateOf(0f) }
    var endF by remember { mutableFloatStateOf(0f) }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("اختر العملية ثم الملف") }

    val pickMain = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            mainUri = uri
            durationMs = editor.durationMs(uri)
            startF = 0f
            endF = durationMs.toFloat()
            status = "تم اختيار الملف (${fmt(durationMs)})"
        }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            audioUri = uri
            status = "تم اختيار ملف الصوت"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("محرر الوسائط", style = MaterialTheme.typography.headlineMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Mode.CUT_VIDEO, Mode.CUT_AUDIO).forEach { m ->
                        FilterChip(
                            selected = mode == m,
                            enabled = !busy,
                            onClick = {
                                mode = m; mainUri = null; audioUri = null
                                durationMs = 0; startF = 0f; endF = 0f
                                status = "اختر الملف"
                            },
                            label = { Text(m.label) }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Mode.REMOVE_AUDIO, Mode.REPLACE_AUDIO).forEach { m ->
                        FilterChip(
                            selected = mode == m,
                            enabled = !busy,
                            onClick = {
                                mode = m; mainUri = null; audioUri = null
                                durationMs = 0; startF = 0f; endF = 0f
                                status = "اختر الملف"
                            },
                            label = { Text(m.label) }
                        )
                    }
                }
            }
        }

        OutlinedButton(
            onClick = { pickMain.launch(mode.pickMime) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (mode.isAudioOutput) "اختيار ملف صوت" else "اختيار فيديو")
        }

        if (mode.needsAudio) {
            OutlinedButton(
                onClick = { pickAudio.launch("audio/*") },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (audioUri == null) "اختيار الصوت الجديد" else "تم اختيار الصوت ✓")
            }
        }

        if (mainUri != null && durationMs > 0 && mode != Mode.REMOVE_AUDIO || (mode == Mode.REMOVE_AUDIO && durationMs > 0)) {
            Text("من ${fmt(startF.toLong())} إلى ${fmt(endF.toLong())}")
            RangeSlider(
                value = startF..endF,
                onValueChange = { startF = it.start; endF = it.endInclusive },
                valueRange = 0f..durationMs.toFloat(),
                enabled = !busy
            )
        }

        Button(
            onClick = {
                val src = mainUri ?: return@Button
                if (mode.needsAudio && audioUri == null) {
                    status = "اختر ملف الصوت أولاً"
                    return@Button
                }
                busy = true
                progress = 0f
                status = "جاري المعالجة..."
                scope.launch {
                    try {
                        val file = editor.export(
                            mode, src, audioUri,
                            startF.toLong(), endF.toLong()
                        ) { progress = it / 100f }
                        val ok = editor.saveToGallery(file, mode.isAudioOutput)
                        status = if (ok) {
                            if (mode.isAudioOutput) "تم الحفظ في Music/MediaEditor ✓"
                            else "تم الحفظ في Movies/MediaEditor ✓"
                        } else "فشل الحفظ"
                    } catch (e: Exception) {
                        status = "حدث خطأ: ${e.message}"
                    } finally {
                        busy = false
                    }
                }
            },
            enabled = !busy && mainUri != null,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("ابدأ")
        }

        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())

        Text(status)
    }
}
