package com.example.mediaeditor

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToLong

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Pal.Purple,
                    background = Pal.Bg1,
                    surface = Pal.Bg1,
                    onSurface = Pal.Text
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = Color.Transparent,
                        contentColor = Pal.Text
                    ) {
                        AppBackground { App() }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThumbBox(label: String, bmp: Bitmap?, modifier: Modifier = Modifier) {
    Box(
        modifier
            .aspectRatio(16 / 9f)
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x22FFFFFF)),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(), contentDescription = null,
                contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(Icons.Rounded.Movie, null, tint = Pal.Muted, modifier = Modifier.size(28.dp))
        }
        Text(
            label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(6.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x99000000))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val editor = remember { Editor(context.applicationContext) }

    var mode by remember { mutableStateOf(Mode.CUT_VIDEO) }
    var mainUri by remember { mutableStateOf<Uri?>(null) }
    var mainName by remember { mutableStateOf("") }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var audioName by remember { mutableStateOf("") }
    var durationMs by remember { mutableLongStateOf(0L) }
    var startMs by remember { mutableLongStateOf(0L) }
    var endMs by remember { mutableLongStateOf(0L) }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var resultUri by remember { mutableStateOf<Uri?>(null) }
    var startThumb by remember { mutableStateOf<Bitmap?>(null) }
    var endThumb by remember { mutableStateOf<Bitmap?>(null) }

    val isVideoMode = !mode.isAudioOutput
    val hasFile = mainUri != null

    fun clearAll() {
        mainUri = null; mainName = ""; audioUri = null; audioName = ""
        durationMs = 0; startMs = 0; endMs = 0
        error = null; resultUri = null; startThumb = null; endThumb = null; progress = 0f
    }

    val pickMain = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            mainUri = uri
            mainName = editor.displayName(uri)
            durationMs = editor.durationMs(uri)
            startMs = 0L
            endMs = durationMs
            error = null; resultUri = null
        }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            audioUri = uri
            audioName = editor.displayName(uri)
            resultUri = null
        }
    }

    LaunchedEffect(mainUri, startMs, mode) {
        val u = mainUri
        if (u != null && isVideoMode && durationMs > 0) {
            delay(250)
            startThumb = withContext(Dispatchers.IO) { editor.frameAt(u, startMs) }
        }
    }
    LaunchedEffect(mainUri, endMs, mode) {
        val u = mainUri
        if (u != null && isVideoMode && durationMs > 0) {
            delay(250)
            endThumb = withContext(Dispatchers.IO) { editor.frameAt(u, (endMs - 100).coerceAtLeast(0L)) }
        }
    }

    val timeError = when {
        !hasFile -> null
        durationMs <= 0 -> "تعذّر قراءة مدة الملف"
        startMs >= endMs -> "وقت البداية لازم يكون قبل وقت النهاية"
        else -> null
    }
    val canRun = hasFile && timeError == null && !busy && (!mode.needsAudio || audioUri != null)

    fun snap(v: Float): Long =
        if (v >= durationMs - 500) durationMs else (v / 1000f).roundToLong() * 1000L

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // ---------- الهيدر ----------
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconBadge(Icons.Rounded.ContentCut, 52)
            Spacer(Modifier.width(14.dp))
            Column {
                Text("محرر الوسائط", color = Pal.Text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("قص • إزالة الصوت • تركيب صوت جديد", color = Pal.Muted, fontSize = 12.sp)
            }
        }

        // ---------- اختيار العملية ----------
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(Mode.CUT_VIDEO, Mode.CUT_AUDIO).forEach { m ->
                ModeCard(m, mode == m, !busy, { mode = m; clearAll() }, Modifier.weight(1f))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(Mode.REMOVE_AUDIO, Mode.REPLACE_AUDIO).forEach { m ->
                ModeCard(m, mode == m, !busy, { mode = m; clearAll() }, Modifier.weight(1f))
            }
        }

        // ---------- اختيار الملف ----------
        GlassCard(Modifier.clickable(enabled = !busy) { pickMain.launch(mode.pickMime) }) {
            if (!hasFile) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconBadge(Icons.Rounded.FolderOpen, 64)
                    Text(
                        if (mode.isAudioOutput) "اختر ملف الصوت" else "اختر الفيديو",
                        color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold
                    )
                    Text("اضغط هنا لتصفح ملفات الجهاز", color = Pal.Muted, fontSize = 12.sp)
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isVideoMode) {
                        ThumbBox("", startThumb, Modifier.width(110.dp))
                    } else {
                        IconBadge(Icons.Rounded.AudioFile, 64)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            mainName, color = Pal.Text, fontWeight = FontWeight.Bold,
                            fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis
                        )
                        Text("المدة الكلية: ${fmt(durationMs)}", color = Pal.Cyan, fontSize = 13.sp)
                        Text("اضغط لتغيير الملف", color = Pal.Muted, fontSize = 11.sp)
                    }
                }
            }
        }

        // ---------- الصوت الجديد ----------
        AnimatedVisibility(
            visible = mode.needsAudio,
            enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
        ) {
            GlassCard(Modifier.clickable(enabled = !busy) { pickAudio.launch("audio/*") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Rounded.LibraryMusic, 48, Pal.Warm)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (audioUri == null) "اختر الصوت الجديد" else audioName,
                            color = Pal.Text, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            if (audioUri == null) "سيحل محل صوت الفيديو" else "اضغط لتغيير الصوت",
                            color = Pal.Muted, fontSize = 12.sp
                        )
                    }
                    if (audioUri != null) {
                        Icon(Icons.Rounded.CheckCircle, null, tint = Pal.Ok, modifier = Modifier.size(26.dp))
                    }
                }
            }
        }

        // ---------- تحديد المدة ----------
        AnimatedVisibility(
            visible = hasFile && durationMs > 0,
            enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
        ) {
            GlassCard {
                SectionTitle(
                    Icons.Rounded.ContentCut,
                    if (mode == Mode.REMOVE_AUDIO) "قص اختياري" else "تحديد المقطع",
                    "اكتب الدقيقة والثانية أو استخدم الشريط"
                )
                Spacer(Modifier.height(14.dp))

                if (isVideoMode) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ThumbBox("البداية", startThumb, Modifier.weight(1f))
                        ThumbBox("النهاية", endThumb, Modifier.weight(1f))
                    }
                } else {
                    Waveform(
                        Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    )
                }
                Spacer(Modifier.height(16.dp))

                TimeRow("البداية", startMs, durationMs, !busy) { startMs = it }
                Spacer(Modifier.height(12.dp))
                TimeRow("النهاية", endMs, durationMs, !busy) { endMs = it }
                Spacer(Modifier.height(8.dp))

                val d = durationMs.toFloat()
                val a = startMs.toFloat().coerceIn(0f, d)
                val b = endMs.toFloat().coerceIn(a, d)
                RangeSlider(
                    value = a..b,
                    onValueChange = { r ->
                        startMs = snap(r.start)
                        endMs = snap(r.endInclusive)
                    },
                    valueRange = 0f..d,
                    enabled = !busy,
                    colors = SliderDefaults.colors(
                        thumbColor = Pal.Cyan,
                        activeTrackColor = Pal.Purple,
                        inactiveTrackColor = Color(0x33FFFFFF)
                    )
                )

                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        if (timeError == null) "المقطع: ${fmt((endMs - startMs).coerceAtLeast(0))}"
                        else "",
                        color = Pal.Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    SoftButton("الملف كله", Icons.Rounded.Refresh) {
                        if (!busy) { startMs = 0L; endMs = durationMs }
                    }
                }

                if (timeError != null) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Warning, null, tint = Pal.Err, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(timeError, color = Pal.Err, fontSize = 13.sp)
                    }
                }
            }
        }

        // ---------- زر التنفيذ ----------
        GradientButton(
            text = if (busy) "جاري المعالجة..." else "ابدأ المعالجة",
            icon = Icons.Rounded.PlayArrow,
            enabled = canRun
        ) {
            val src = mainUri ?: return@GradientButton
            scope.launch {
                busy = true; progress = 0f; error = null; resultUri = null
                try {
                    val file = editor.export(mode, src, audioUri, startMs, endMs) { progress = it / 100f }
                    val uri = editor.saveToGallery(file, mode.isAudioOutput)
                    if (uri != null) resultUri = uri else error = "فشل حفظ الملف"
                } catch (e: Exception) {
                    error = "حدث خطأ: ${e.message}"
                } finally {
                    busy = false
                }
            }
        }

        // ---------- التقدم ----------
        AnimatedVisibility(
            visible = busy,
            enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
        ) {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(
                        progress = { progress },
                        color = Pal.Cyan,
                        trackColor = Color(0x33FFFFFF),
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("${(progress * 100).toInt()}%", color = Pal.Text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("لا تغلق التطبيق أثناء المعالجة", color = Pal.Muted, fontSize = 12.sp)
                    }
                }
            }
        }

        // ---------- النتيجة ----------
        AnimatedVisibility(
            visible = resultUri != null,
            enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
        ) {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.CheckCircle, null, tint = Pal.Ok, modifier = Modifier.size(40.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("تم بنجاح!", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (mode.isAudioOutput) "محفوظ في Music/MediaEditor" else "محفوظ في Movies/MediaEditor",
                            color = Pal.Muted, fontSize = 12.sp
                        )
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SoftButton("فتح", Icons.Rounded.PlayArrow, Modifier.weight(1f)) {
                        resultUri?.let { u ->
                            try {
                                context.startActivity(
                                    Intent(Intent.ACTION_VIEW)
                                        .setDataAndType(u, if (mode.isAudioOutput) "audio/mp4" else "video/mp4")
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                )
                            } catch (e: Exception) {
                                error = "لا يوجد تطبيق لفتح الملف"
                            }
                        }
                    }
                    SoftButton("مشاركة", Icons.Rounded.Share, Modifier.weight(1f)) {
                        resultUri?.let { u ->
                            try {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = if (mode.isAudioOutput) "audio/mp4" else "video/mp4"
                                    putExtra(Intent.EXTRA_STREAM, u)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(send, "مشاركة"))
                            } catch (e: Exception) {
                                error = "تعذرت المشاركة"
                            }
                        }
                    }
                }
            }
        }

        // ---------- الخطأ ----------
        AnimatedVisibility(
            visible = error != null,
            enter = fadeIn() + expandVertically(), exit = fadeOut() + shrinkVertically()
        ) {
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Warning, null, tint = Pal.Err, modifier = Modifier.size(24.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(error ?: "", color = Pal.Err, fontSize = 13.sp)
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}
