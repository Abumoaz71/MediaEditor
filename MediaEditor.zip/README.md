# محرر الوسائط (Media Editor)

تطبيق أندرويد بتصميم عصري (Kotlin + Jetpack Compose + Media3 Transformer):
- قص الفيديو
- قص الصوت
- إزالة الصوت من الفيديو
- تركيب صوت جديد على الفيديو

الناتج يُحفظ في `Movies/MediaEditor` أو `Music/MediaEditor`. الحد الأدنى: Android 10.

## بناء الـ APK على GitHub
1. ارفع كل الملفات (بما فيها مجلد `.github`) على Repository.
2. أي Push على `main` يشغّل **Actions** تلقائياً.
3. بعد انتهاء البناء: **Actions ← آخر تشغيل ← Artifacts ← MediaEditor-debug-apk**.
4. للنشر في Releases: أنشئ Tag مثل `v1.0` وسيُرفق الـ APK تلقائياً.
